package pi;

/**
 * A unit vector is a vector of length equal to one.
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
public class VecUnit extends Vec {

    public final static VecUnit X = new VecUnit(1, 0, 0);
    public final static VecUnit Y = new VecUnit(0, 1, 0);
    public final static VecUnit Z = new VecUnit(0, 0, 1);

    VecUnit(int x, int y, int z) {
        super(x, y, z);
    }

    @Override
    public VecUnit neg() {
        return new VecUnit(-x, -y, -z);
    }
}
