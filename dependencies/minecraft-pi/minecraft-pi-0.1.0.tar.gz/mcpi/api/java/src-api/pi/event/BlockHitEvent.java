package pi.event;

import pi.VecUnit;
import pi.Vec;

/**
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
public class BlockHitEvent extends BlockEvent {

    public final VecUnit surfaceDirection;
    public final int entityId;

    public BlockHitEvent(Vec position, VecUnit surfaceDirection, int entityId) {
        super(position);
        this.surfaceDirection = surfaceDirection;
        this.entityId = entityId;
    }
}
