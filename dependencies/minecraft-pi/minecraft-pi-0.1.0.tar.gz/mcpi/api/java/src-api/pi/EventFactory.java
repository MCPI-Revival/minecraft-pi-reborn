package pi;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static pi.VecUnit.*;
import pi.event.BlockHitEvent;

/**
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
class EventFactory {

    static List<BlockHitEvent> createBlockHitEvents(String eventList) {
        List<BlockHitEvent> events = new ArrayList<>();

        if (!eventList.isEmpty()) {
            for (String event : eventList.split("\\|")) {
                Scanner s = new Scanner(event).useDelimiter(",");
                Vec position = Vec.xyz(s.nextInt(), s.nextInt(), s.nextInt());
                VecUnit surfaceDirection = faceIdxToDirection(s.nextInt());
                int entityId = s.nextInt();
                events.add(new BlockHitEvent(position, surfaceDirection, entityId));
            }
        }

        return events;
    }

    static VecUnit faceIdxToDirection(int faceIdx) {
        VecUnit[] faceDirs = {Y.neg(), Y, Z.neg(), Z, X.neg(), X};
        return faceDirs[faceIdx];
    }
}
